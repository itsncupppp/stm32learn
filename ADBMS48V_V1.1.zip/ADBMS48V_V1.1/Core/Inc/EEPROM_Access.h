/*
 * EEPROM_Access.h
 *
 *  Created on: Sep 18, 2024
 *      Author: hp
 */

#ifndef INC_EEPROM_ACCESS_H_
#define INC_EEPROM_ACCESS_H_

#include "stdint.h"
#include "stm32f1xx_hal.h"
#include "i2c.h"
#include "stdio.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define EEPROM_ADDRESS 0xA0
void EEPROM_isDeviceReady(uint16_t addr);
uint16_t bytestowrite (uint16_t size, uint16_t offset);
void EEPROM_Write (uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);
void EEPROM_Read (uint16_t page, uint16_t offset, uint8_t *data, uint16_t size);
uint8_t EEPROM_ReadData(uint16_t addr);
void EEPROM_WriteChar(uint16_t addr, char data_char[]);
void EEPROM_ReadChar(uint16_t addr0, uint16_t addrn, uint8_t data_read_char[]);
void EEPROM_PageErase (uint16_t page);


#endif /* INC_EEPROM_ACCESS_H_ */
