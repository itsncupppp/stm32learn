/*
 * BatterySystem.h
 *
 *  Created on: Sep 20, 2024
 *      Author: hp
 */

#ifndef INC_BATTERYSYSTEM_H_
#define INC_BATTERYSYSTEM_H_

extern uint8_t	cycle, flag_write_cycle;
extern uint8_t BATT_State;
void check_SOC_Based_OCV(void);
void Batt_Open_Mode(void);
void Batt_Charge_Mode(void);
void Batt_Discharge_Mode(void);
void Batt_Full_CD_Mode(void);

#endif /* INC_BATTERYSYSTEM_H_ */
