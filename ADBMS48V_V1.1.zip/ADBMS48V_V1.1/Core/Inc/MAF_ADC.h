/*
 * MAF_ADC.h
 *
 *  Created on: Sep 13, 2024
 *      Author: hp
 */

#ifndef INC_MAF_ADC_H_
#define INC_MAF_ADC_H_

#include <stdint.h>

#define MAF_Size 10

float calculate_temperature(float ntc_resistance);
float calculate_NTC_Resistance(uint16_t adc_value);
void process_AllADCChannel(uint16_t ADC_Data[]);

extern float AverageValue[9];
extern float sumTotal[9];
extern uint8_t indxData[9];
extern float SampleData[9][MAF_Size];
extern uint16_t ADC_Value[9];
extern float NTCRes[9];
extern uint8_t MOSTemp[4], BATTtemp[4], RshuntTemp;

#endif /* INC_MAF_ADC_H_ */
