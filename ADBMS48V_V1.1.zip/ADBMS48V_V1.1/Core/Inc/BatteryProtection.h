/*
 * BatteryProtection.h
 *
 *  Created on: Sep 20, 2024
 *      Author: hp
 */

#ifndef INC_BATTERYPROTECTION_H_
#define INC_BATTERYPROTECTION_H_

#define maxdata 200				//jumlah sampling rata-rata ADC
#define interval_hitungsuhu 200	//delay update nilai sensor suhu = 10 x periode timer 2

extern uint8_t 	    Tick_BattId, Tick_33ms;

//Variabel arus
extern float	    sum_current;

// Parameter tambahan baterai
extern float 	    AH_Consumption, AH_Total;
extern uint16_t 	time_soc;
extern uint32_t 	cek_CC;

extern const float Pack_Cap;

extern uint8_t		BATT_State;
extern uint8_t  	BATT_Start_Up;

// Variable setting proteksi
extern float 	    I_Over_Set,
		            I_Over_Set_Charge,
		            Disc_OverTemp,
		            Chg_OverTemp,
		            Temp_Under_Set,
		            SOC_Under_Set,
		            SOC_Over_Set,
		            V_Under_Set,
		            V_Over_Set,
		            Persen_Imbalance_Set;

//Variable bantu proteksi
extern float	    TMS;
extern float 	    TMS_I_Over;
extern float 	    T_Under_trip,
		            T_trip_cycle;
extern uint8_t      Clear_Trip_undervoltage,
		            Clear_Trip_overcurrentdischarge;
extern uint16_t     test_timer;
extern float 	    SOC_Flow;

#endif /* INC_BATTERYPROTECTION_H_ */
