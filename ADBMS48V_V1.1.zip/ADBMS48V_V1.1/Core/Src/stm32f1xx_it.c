/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f1xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "can.h"
#include "math.h"
#include "MAF_ADC.h"
#include "BatteryProtection.h"
#include "BatterySystem.h"

#define maxdata 200				//jumlah sampling rata-rata ADC
#define interval_hitungsuhu 200	//delay update nilai sensor suhu = 10 x periode timer 2

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

uint16_t	 hitung_suhu, i;
extern float pack_voltage, Current;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern DMA_HandleTypeDef hdma_adc1;
extern ADC_HandleTypeDef hadc1;
extern CAN_HandleTypeDef hcan;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M3 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F1xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f1xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles DMA1 channel1 global interrupt.
  */
void DMA1_Channel1_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Channel1_IRQn 0 */

  /* USER CODE END DMA1_Channel1_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_adc1);
  /* USER CODE BEGIN DMA1_Channel1_IRQn 1 */

  /* USER CODE END DMA1_Channel1_IRQn 1 */
}

/**
  * @brief This function handles ADC1 and ADC2 global interrupts.
  */
void ADC1_2_IRQHandler(void)
{
  /* USER CODE BEGIN ADC1_2_IRQn 0 */

  /* USER CODE END ADC1_2_IRQn 0 */
  HAL_ADC_IRQHandler(&hadc1);
  /* USER CODE BEGIN ADC1_2_IRQn 1 */

  /* USER CODE END ADC1_2_IRQn 1 */
}

/**
  * @brief This function handles USB low priority or CAN RX0 interrupts.
  */
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  /* USER CODE BEGIN USB_LP_CAN1_RX0_IRQn 0 */

  /* USER CODE END USB_LP_CAN1_RX0_IRQn 0 */
  HAL_CAN_IRQHandler(&hcan);
  /* USER CODE BEGIN USB_LP_CAN1_RX0_IRQn 1 */

  /* USER CODE END USB_LP_CAN1_RX0_IRQn 1 */
}

/**
  * @brief This function handles TIM2 global interrupt.
  */
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */

  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */

  hitung_suhu++;

  VBATT = pack_voltage;
  IBATT = Current;

  if (hitung_suhu >= interval_hitungsuhu){

	  process_AllADCChannel(ADC_Data);

	  if(BATTtemp[0]>=130) BATTtemp[0] = 130;
	  if(BATTtemp[1]>=130) BATTtemp[1] = 130;
	  if(BATTtemp[2]>=130) BATTtemp[2] = 130;
	  if(BATTtemp[3]>=130) BATTtemp[3] = 130;
	  if(MOSTemp[0]>=130) MOSTemp[0] = 130;
	  if(MOSTemp[1]>=130) MOSTemp[1] = 130;
	  if(MOSTemp[2]>=130) MOSTemp[2] = 130;
	  if(MOSTemp[3]>=130) MOSTemp[3] = 130;
	  if(RshuntTemp>=130) RshuntTemp = 130;

	  hitung_suhu = 0;
  }

  if (BATT_Start_Up == 1)
  {
		if (BATT_State == STATE_DISCHARGE) {
			RunDischargingProtection();
		} else if (BATT_State == STATE_CHARGE) {
			RunChargingProtection();
		}
		if (BATT_State == STATE_FULL_CHARGE_DISCHARGE) {
			RunFULLCDProtection();
		}

		//********************* Clearing protection status *****************************////
		// ---> Clearing UnderVoltage
		if(((Clear_Trip_undervoltage==1)||(VBATT>30))&&flag_trip_undervoltage==ON){
			flag_trip_undervoltage=OFF;
			Clear_Trip_undervoltage=0;
		}
		// ---> Clearing OverCurrent Discharge
		if(flag_trip_overcurrentdischarge==ON && Clear_Trip_overcurrentdischarge==1){
			flag_trip_overcurrentdischarge=OFF;
			Clear_Trip_overcurrentdischarge=0;
		}
		// ---> Clearing OverTemperature
		if(flag_trip_overtemperature==ON && (BATTtemp[0]<45)&&(BATTtemp[1]<45)&&(BATTtemp[2]<45)&&(BATTtemp[3]<45)){
			flag_trip_overtemperature=OFF;
		}
		// ---> Clearing UnderTemperature
		if(flag_trip_undertemperature==ON && (BATTtemp[0]>20)&&(BATTtemp[1]>20)&&(BATTtemp[2]>20)&&(BATTtemp[3]>20)){
			flag_trip_undertemperature=OFF;
		}
		// ---> Clearing OverDischarge
		if(flag_trip_SOCOverDischarge==ON && Pack_SOC>0){
			flag_trip_SOCOverDischarge=OFF;
		}
		// ---> Clearing OverCharge
		if(flag_trip_SOCOverCharge==ON && Pack_SOC<100){
			flag_trip_SOCOverCharge=OFF;
		}
		// ---> Clearing Cell Over Voltage
		if(flag_trip_cellovervoltage==ON && Cell_OverVoltage == NO){
			flag_trip_cellovervoltage = OFF;
		}
		// ---> Clearing Cell Under Voltage
		if(flag_trip_cellundervoltage==ON && Cell_UnderVoltage == NO){
			flag_trip_cellundervoltage = OFF;
		}

	}
	i++;
	i=i%maxdata;

	//////////// Bagian Hitung SOC /////// SOC akan dihitung berdasarkan state baterai (Jika charge maupun discharge)
	if(BATT_State==STATE_CHARGE||BATT_State==STATE_DISCHARGE||BATT_State==STATE_FULL_CHARGE_DISCHARGE)
	{

		time_soc++;
		sum_current+=IBATT;
		if(time_soc>99)
		{
			AH_Consumption += (-1*sum_current)/100*(1.0/3600.0);
			SOC_Flow = (AH_Consumption/Pack_Cap)*100;
			Pack_SOC = Pack_SOC+SOC_Flow;
			time_soc = 0;
			sum_current = 0;

			grad=(100-0)/(batas_atas-batas_bawah);
			constanta=grad*batas_bawah*(-1);
			SOC_manipulasi=grad*Pack_SOC+constanta;

			test_timer++;
		}
	}

  /* USER CODE END TIM2_IRQn 1 */
}

/**
  * @brief This function handles TIM3 global interrupt.
  */
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */

  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */

  if(flag_start_shutdown==1){
  if(Tick_33ms == 1) CANTX_BattParameter();
  else if(Tick_33ms == 2) CANTX_BattProtection();
  else if(Tick_33ms == 3) {
  		CANTX_ReportToCharger();
  		Tick_33ms = 0;
  		}
  if(Tick_BattId > 30) {
  		CANTX_BattId();
  		Tick_BattId = 0;
  		}
  	Tick_33ms++;
  	Tick_BattId++;
  }

  /* USER CODE END TIM3_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
