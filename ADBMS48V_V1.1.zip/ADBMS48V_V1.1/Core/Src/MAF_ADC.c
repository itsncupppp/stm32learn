/*
 * MAF_ADC.c
 *
 *  Created on: Sep 13, 2024
 *      Author: itsncuppp_
 */

#include "main.h"
#include "MAF_ADC.h"
#include "stm32f1xx_hal.h"
#include "math.h"

#define B_CONSTANT 3900.0   // B-Constant untuk NTC (dalam Kelvin)
#define T0 298.15           // Suhu referensi (25°C dalam Kelvin)
#define R_FIXED 10000.0     // Resistor tetap 10KΩ
#define V_REF 3.25           // Tegangan referensi 3.3V

uint8_t indxData[9] = {0};
uint16_t ADC_Value[9];
float AverageValue[9] = {0};
float sumTotal[9] = {0};
float SampleData[9][MAF_Size] = {0};
float NTCRes[9];
uint8_t MOSTemp[4], BATTtemp[4], RshuntTemp;

// Kalkulasi Nilai Resistansi NTC
float calculate_NTC_Resistance(uint16_t adc_value) {
    float voltage = (adc_value * V_REF) / 4095.0;
    return (R_FIXED * voltage) / (V_REF - voltage);
}

// Kalkulasi Suhu Mosfet Berdasarkan Perubahan Nilai Resistansi NTC
float calculate_temperature(float ntc_resistance) {
    float temperature = (1.0 / (log(ntc_resistance / R_FIXED) / B_CONSTANT + (1.0 / T0))) - 273.15;
    return temperature;
}

// Filter Data ADC Menggunakan Movig Average Filter dan Proses Data ADC
void process_AllADCChannel( uint16_t ADC_Data[] ) {

    for (int ch = 0; ch < 9; ch++) {
        ADC_Value[ch] = ADC_Data[ch];

        sumTotal[ch] -= SampleData[ch][indxData[ch]];
        SampleData[ch][indxData[ch]] = ADC_Value[ch];
        sumTotal[ch] += SampleData[ch][indxData[ch]];
        AverageValue[ch] = sumTotal[ch] / MAF_Size;

        indxData[ch] = (indxData[ch] + 1) % MAF_Size;
    }

    // AverageValue[0]-[3] = LowCell, MidCell, HighCell, SpareTemp
    // AverageValue[4]-[7] = Mosfet Temperature
    // AverageValue[8] = Rshunt Temperature

    //Proces Konversi Data ADC Mosfet Temperature
    for (int i = 0; i < 4; i++) {
        NTCRes[i] = calculate_NTC_Resistance(AverageValue[i + 4]);
        MOSTemp[i] = calculate_temperature(NTCRes[i]);
        MOSWrite[i] = MOSTemp[i];
    }

    //Process Konversi Data ADC Temeprature Baterai
    for (int i=0; i<4; i++){
    	NTCRes[i + 4] = calculate_NTC_Resistance(AverageValue[i]);
    	BATTtemp[i] = calculate_temperature(NTCRes[i + 4]);
    }

    //Proses Konversi Data ADC Rshunt Temperature
    NTCRes[8] = calculate_NTC_Resistance(AverageValue[8]);
    RshuntTemp = calculate_temperature(NTCRes[8]);

}

