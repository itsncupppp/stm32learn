/*
 * BatteryProtection.c
 *
 *  Created on: Sep 20, 2024
 *      Author: hp
 */

#include "stm32f1xx_hal.h"
#include "main.h"
#include "gpio.h"
#include "MAF_ADC.h"
#include "BatterySystem.h"
#include "BatteryProtection.h"
#include "math.h"

uint8_t 	Tick_BattId, Tick_33ms;

//Variabel arus dan tegangan
extern float pack_voltage, Current;
float		 sum_current;

//Battery Pack Rated Capacity
const float Pack_Cap = 54;

// Parameter tambahan baterai
float 		AH_Consumption, AH_Total=0;
uint16_t 	time_soc;
uint32_t 	cek_CC=0;
uint8_t 	BATT_Start_Up;

// Variable setting proteksi
float 	I_Over_Set = 50,
		I_Over_Set_Charge = 20,
		Disc_OverTemp = 55,
		Chg_OverTemp = 45,
		Temp_Under_Set = 10,
		SOC_Under_Set = 0,
		SOC_Over_Set = 120,
		V_Under_Set = 29,
		V_Over_Set = 45,
		Persen_Imbalance_Set=20;

//Variable bantu proteksi
float	TMS=0.5;
float 	TMS_I_Over=120;
float 	T_Under_trip,
		T_trip_cycle;
uint8_t Clear_Trip_undervoltage,
		Clear_Trip_overcurrentdischarge;
uint16_t test_timer;
float 	SOC_Flow;

void RunChargingProtection(void){
	//***************** Short Circuit Protection ***********************************//
	if(IBATT > (VBATT)) {
		Isc = IBATT;
		Vsc = VBATT;
		fault_code = 12;
		Batt_Open_Mode();
		flag_trip_shortcircuit = ON;
		HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
	}

	//**************Pengecekan OverCharge****************************//
	else if(Pack_SOC >= SOC_Over_Set-10 && flag_trip_SOCOverCharge==OFF) {
		fault_code=7;
		if(Pack_SOC>SOC_Over_Set){
			Batt_Open_Mode();
			flag_trip_SOCOverCharge=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//**************Pengecekan OverTemperature ****************************//
	else if(((BATTtemp[0]>Chg_OverTemp)||(BATTtemp[1]>Chg_OverTemp)||(BATTtemp[2]>Chg_OverTemp)||(BATTtemp[3]>Chg_OverTemp)) && flag_trip_overtemperature==OFF) {
		fault_code=3;
		if(BATTtemp[0]>Chg_OverTemp && BATTtemp[0]<=Chg_OverTemp+1) {
			if((test_tim2%1000)==0) {
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Chg_OverTemp+1 && BATTtemp[0]<=Chg_OverTemp+2){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Chg_OverTemp+2 && BATTtemp[0]<=Chg_OverTemp+3){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Chg_OverTemp+3||BATTtemp[1]>Chg_OverTemp+3||BATTtemp[3]>Chg_OverTemp+3||BATTtemp[3]>Chg_OverTemp+3){
			Batt_Open_Mode();
			flag_trip_overtemperature=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//**************Pengecekan UnderTemperature ****************************//
	else if((BATTtemp[0]-Temp_Under_Set<=10||BATTtemp[1]-Temp_Under_Set<=10||BATTtemp[2]-Temp_Under_Set<=10||BATTtemp[3]-Temp_Under_Set<=10) && flag_trip_undertemperature==OFF) {
		fault_code=4;
		if(BATTtemp[0]<=Temp_Under_Set+10 && BATTtemp[0]>Temp_Under_Set+5){
			if((test_tim2%1000)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<=Temp_Under_Set+5 && BATTtemp[0]>Temp_Under_Set+2){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<Temp_Under_Set+2 && BATTtemp[0]>=Temp_Under_Set){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<Temp_Under_Set||BATTtemp[1]<Temp_Under_Set||BATTtemp[2]<Temp_Under_Set||BATTtemp[3]<Temp_Under_Set){
			Batt_Open_Mode();
			flag_trip_undertemperature=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//**************Pengecekan OverCurrent Charge **********************//
	else if((fabs(IBATT)-I_Over_Set_Charge)>0 && flag_trip_overcurrentcharge==OFF) {  //Indikasi terjadi Over Current
		fault_code=10;
		T_I_Over_trip=8/(((IBATT/6.9)*(IBATT/6.9))-1);
		T_I_Over_trip_cycle+=0.01;

		if(T_I_Over_trip_cycle>T_I_Over_trip && flag_trip_overcurrentcharge==OFF) {
			Batt_Open_Mode();
			T_I_Over_trip_cycle=T_I_Over_trip;
			flag_trip_overcurrentcharge=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}

		if(flag_trip_overcurrentcharge==OFF) {
			if(T_I_Over_trip-T_I_Over_trip_cycle>15) {
				if((test_tim2%1000)==0) {
					BUZZ_Toggle;
					test_tim2=0;
				}
			}
			else if(T_I_Over_trip-T_I_Over_trip_cycle>10) {
				if((test_tim2%100)==0) {
					BUZZ_Toggle;
					test_tim2=0;
				}
			}
			else if(T_I_Over_trip-T_I_Over_trip_cycle>3) {
				if((test_tim2%10)==0) {
					BUZZ_Toggle;
					test_tim2=0;
				}
			}
			else if(T_I_Over_trip-T_I_Over_trip_cycle>1) {
				HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);
			}
		}
	}

	///////////////////// Overvoltage Protection//////////////////////////////
	else if(VBATT>V_Over_Set) {
		fault_code=11;
		flag_trip_overvoltage=ON;
		Batt_Open_Mode();
	}

	//Clearing when data status is normal before system trip
	else {
		if(fault_code!=0){
			last_fault_code=fault_code;
		}
		fault_code=0;
		T_Under_trip=0;
		T_trip_cycle=T_trip_cycle-0.001;
		T_I_Over_trip_cycle-=0.001;
		HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);

		if(T_trip_cycle<0)
			T_trip_cycle=0;
		if(T_I_Over_trip_cycle<0)
			T_I_Over_trip_cycle=0;
	}
}

void RunDischargingProtection(void) {
	//***************** Short Circuit Protection ***********************************//
	if(IBATT > (VBATT/0.5)) {
		Isc = IBATT;
		Vsc = VBATT;
		fault_code = 12;
		Batt_Open_Mode();
		flag_trip_shortcircuit = ON;
		HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
	}

	//***************** Undervoltage Protection ***********************************//
	else if(VBATT<V_Under_Set && flag_trip_undervoltage==OFF ) {   //Indikasi terjadi Undervoltage
		fault_code=1;
		T_Under_trip=TMS/(1-(VBATT/V_Under_Set));
		T_trip_cycle+=0.001;

		if(T_trip_cycle>T_Under_trip && flag_trip_undervoltage==OFF) {
			Batt_Open_Mode();
			T_trip_cycle=T_Under_trip;
			flag_trip_undervoltage=ON;
			HAL_GPIO_WritePin(GATE_MOS_GPIO_Port, GATE_MOS_Pin, GPIO_PIN_RESET);
		}
	}

	//************** OverCurrent Discharge **********************//
	else if((IBATT-I_Over_Set)>0 && flag_trip_overcurrentdischarge==OFF) {   //Indikasi terjadi Over Current
		fault_code=2;
		T_I_Over_trip=I_Over_Set/(((IBATT/6.9)*(IBATT/6.9))-1);
		T_I_Over_trip_cycle+=0.01;

		if(T_I_Over_trip_cycle>T_I_Over_trip && flag_trip_overcurrentdischarge==OFF) {
			Batt_Open_Mode();
			T_I_Over_trip_cycle=T_I_Over_trip;
			flag_trip_overcurrentdischarge=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
		if(flag_trip_overcurrentdischarge==OFF) {
			if(T_I_Over_trip-T_I_Over_trip_cycle>15) {
				if((test_tim2%1000)==0) {
					BUZZ_Toggle;
					test_tim2=0;
				}
			}
			else if(T_I_Over_trip-T_I_Over_trip_cycle>10){
				if((test_tim2%100)==0){
					BUZZ_Toggle;
					test_tim2=0;
				}
			}
			else if(T_I_Over_trip-T_I_Over_trip_cycle>3){
				if((test_tim2%10)==0){
					BUZZ_Toggle;
					test_tim2=0;
				}
			}
			else if(T_I_Over_trip-T_I_Over_trip_cycle>1){
				HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);
			}
		}
	}

	//**************Pengecekan OverTemperature ****************************//
	else if(((BATTtemp[0]>Disc_OverTemp)||(BATTtemp[1]>Disc_OverTemp)||(BATTtemp[2]>Disc_OverTemp)||(BATTtemp[3]>Disc_OverTemp)) && flag_trip_overtemperature==OFF) {
		fault_code=3;
		if(BATTtemp[0]>Disc_OverTemp && BATTtemp[0]<=Disc_OverTemp+1) {
			if((test_tim2%1000)==0) {
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Disc_OverTemp+1 && BATTtemp[0]<=Disc_OverTemp+2){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Disc_OverTemp+2 && BATTtemp[0]<=Disc_OverTemp+3){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Disc_OverTemp+3||BATTtemp[1]>Disc_OverTemp+3||BATTtemp[2]>Disc_OverTemp+3||BATTtemp[3]>Disc_OverTemp+3){
			Batt_Open_Mode();
			flag_trip_overtemperature=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//**************Pengecekan UnderTemperature ****************************//
	else if((BATTtemp[0]-Temp_Under_Set<=10||BATTtemp[1]-Temp_Under_Set<=10||BATTtemp[2]-Temp_Under_Set<=10||BATTtemp[3]-Temp_Under_Set<=10) && flag_trip_undertemperature==OFF) {
		fault_code=4;
		if(BATTtemp[0]<=Temp_Under_Set+10 && BATTtemp[0]>Temp_Under_Set+5){
			if((test_tim2%1000)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<=Temp_Under_Set+5 && BATTtemp[0]>Temp_Under_Set+2){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<Temp_Under_Set+2 && BATTtemp[0]>=Temp_Under_Set){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<Temp_Under_Set||BATTtemp[1]<Temp_Under_Set||BATTtemp[2]<Temp_Under_Set||BATTtemp[3]<Temp_Under_Set){
			Batt_Open_Mode();
			flag_trip_undertemperature=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//********************** SOC_OverDischarge****************************//
	else if(Pack_SOC <= SOC_Under_Set+5 && flag_trip_SOCOverDischarge==OFF && BATT_State==STATE_DISCHARGE) {
		fault_code=5;
		if(Pack_SOC <= SOC_Under_Set+5 && Pack_SOC>SOC_Under_Set+3){
			if((test_tim2%1000)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(Pack_SOC <= SOC_Under_Set+3 && Pack_SOC>SOC_Under_Set+2){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(Pack_SOC <= SOC_Under_Set+2 && Pack_SOC>SOC_Under_Set){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(Pack_SOC <= SOC_Under_Set){
			Batt_Open_Mode();
			flag_trip_SOCOverDischarge=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//********************** Imbalance Checking Status ****************************//
	else if(persen_imbalance >= Persen_Imbalance_Set + 5)
	{
		fault_code=6;
		if(persen_imbalance >= Persen_Imbalance_Set)
		{
			flag_trip_unbalance=ON;
			Batt_Open_Mode();
		}
	}

	//Clearing when data status is normal before system trip
	else {
		if(fault_code!=0){
			last_fault_code=fault_code;
		}
		fault_code=0;
		T_Under_trip=0;
		T_trip_cycle=T_trip_cycle-0.001;
		T_I_Over_trip_cycle-=0.001;
		HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);

		if(T_trip_cycle<0)
			T_trip_cycle=0;
		if(T_I_Over_trip_cycle<0)
			T_I_Over_trip_cycle=0;
	}
}

void RunFULLCDProtection(void) {
	//***************** Short Circuit Protection ***********************************//
	if(IBATT > (VBATT)) {
		Isc = IBATT;
		Vsc = VBATT;
		fault_code = 12;
		Batt_Open_Mode();
		flag_trip_shortcircuit = ON;
		HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
	}

	//**************Pengecekan OverCharge****************************//
	else if(Pack_SOC >= SOC_Over_Set-10 && flag_trip_SOCOverCharge==OFF) {
		fault_code=7;
		if(Pack_SOC>SOC_Over_Set){
			Batt_Open_Mode();
			flag_trip_SOCOverCharge=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//***************** Undervoltage Protection ***********************************//
		else if(VBATT<V_Under_Set && flag_trip_undervoltage==OFF ) {   //Indikasi terjadi Undervoltage
			fault_code=1;
			T_Under_trip=TMS/(1-(VBATT/V_Under_Set));
			T_trip_cycle+=0.001;

			if(T_trip_cycle>T_Under_trip && flag_trip_undervoltage==OFF) {
				Batt_Open_Mode();
				T_trip_cycle=T_Under_trip;
				flag_trip_undervoltage=ON;
				HAL_GPIO_WritePin(GATE_MOS_GPIO_Port, GATE_MOS_Pin, GPIO_PIN_RESET);
			}
		}

	//**************Pengecekan OverCurrent Charge **********************//
		else if((fabs(IBATT)-I_Over_Set_Charge)>0 && flag_trip_overcurrentcharge==OFF) {  //Indikasi terjadi Over Current
			fault_code=10;
			T_I_Over_trip=8/(((IBATT/6.9)*(IBATT/6.9))-1);
			T_I_Over_trip_cycle+=0.01;

			if(T_I_Over_trip_cycle>T_I_Over_trip && flag_trip_overcurrentcharge==OFF) {
				Batt_Open_Mode();
				T_I_Over_trip_cycle=T_I_Over_trip;
				flag_trip_overcurrentcharge=ON;
				HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
			}

			if(flag_trip_overcurrentcharge==OFF) {
				if(T_I_Over_trip-T_I_Over_trip_cycle>15) {
					if((test_tim2%1000)==0) {
						BUZZ_Toggle;
						test_tim2=0;
					}
				}
				else if(T_I_Over_trip-T_I_Over_trip_cycle>10) {
					if((test_tim2%100)==0) {
						BUZZ_Toggle;
						test_tim2=0;
					}
				}
				else if(T_I_Over_trip-T_I_Over_trip_cycle>3) {
					if((test_tim2%10)==0) {
						BUZZ_Toggle;
						test_tim2=0;
					}
				}
				else if(T_I_Over_trip-T_I_Over_trip_cycle>1) {
					HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET);
				}
			}
		}

	//**************Pengecekan OverTemperature ****************************//
	else if(((BATTtemp[0]>Chg_OverTemp)||(BATTtemp[1]>Chg_OverTemp)||(BATTtemp[2]>Chg_OverTemp)||(BATTtemp[3]>Chg_OverTemp)) && flag_trip_overtemperature==OFF) {
		fault_code=3;
		if(BATTtemp[0]>Chg_OverTemp && BATTtemp[0]<=Chg_OverTemp+1) {
			if((test_tim2%1000)==0) {
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Chg_OverTemp+1 && BATTtemp[0]<=Chg_OverTemp+2){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Chg_OverTemp+2 && BATTtemp[0]<=Chg_OverTemp+3){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]>Chg_OverTemp+3||BATTtemp[1]>Chg_OverTemp+3||BATTtemp[2]>Chg_OverTemp+3||BATTtemp[3]>Chg_OverTemp+3){
			Batt_Open_Mode();
			flag_trip_overtemperature=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	// Under Temperature protection
	else if((BATTtemp[0]-Temp_Under_Set<=10||BATTtemp[1]-Temp_Under_Set<=10||BATTtemp[2]-Temp_Under_Set<=10||BATTtemp[3]-Temp_Under_Set<=10) && flag_trip_undertemperature==OFF) {
		fault_code=4;
		if(BATTtemp[0]<=Temp_Under_Set+10 && BATTtemp[0]>Temp_Under_Set+5) {
			if((test_tim2%1000)==0) {
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<=Temp_Under_Set+5 && BATTtemp[0]>Temp_Under_Set+2) {
			if((test_tim2%500)==0) {
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<Temp_Under_Set+2 && BATTtemp[0]>=Temp_Under_Set) {
			if((test_tim2%500)==0) {
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(BATTtemp[0]<Temp_Under_Set||BATTtemp[1]<Temp_Under_Set||BATTtemp[2]<Temp_Under_Set||BATTtemp[3]<Temp_Under_Set) {
			Batt_Open_Mode();
			flag_trip_undertemperature=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//********************** SOC_OverDischarge****************************//
	else if(Pack_SOC <= SOC_Under_Set+5 && flag_trip_SOCOverDischarge==OFF && BATT_State==STATE_DISCHARGE) {
		fault_code=5;
		if(Pack_SOC <= SOC_Under_Set+5 && Pack_SOC>SOC_Under_Set+3){
			if((test_tim2%1000)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(Pack_SOC <= SOC_Under_Set+3 && Pack_SOC>SOC_Under_Set+2){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(Pack_SOC <= SOC_Under_Set+2 && Pack_SOC>SOC_Under_Set){
			if((test_tim2%500)==0){
				BUZZ_Toggle;
				test_tim2=0;
			}
		}
		else if(Pack_SOC <= SOC_Under_Set){
			Batt_Open_Mode();
			flag_trip_SOCOverDischarge=ON;
			HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
		}
	}

	//********************** Imbalance Checking Status ****************************//
	else if(persen_imbalance >= Persen_Imbalance_Set + 5)
	{
		fault_code=6;
		if(persen_imbalance >= Persen_Imbalance_Set)
		{
			flag_trip_unbalance=ON;
			Batt_Open_Mode();
		}
	}

	//Clearing when data status is normal before system trip
	else {
		if(fault_code!=0){
			last_fault_code=fault_code;
		}
		fault_code=0;
		T_Under_trip=0;
		T_trip_cycle=T_trip_cycle-0.001;
		T_I_Over_trip_cycle-=0.001;
		HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);

		if(T_trip_cycle<0)
			T_trip_cycle=0;
		if(T_I_Over_trip_cycle<0)
			T_I_Over_trip_cycle=0;
	}
}
