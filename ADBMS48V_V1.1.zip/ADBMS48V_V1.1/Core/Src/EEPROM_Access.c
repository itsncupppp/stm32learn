/*
 * EEPROM_Access.c
 *
 *  Created on: Sep 18, 2024
 *      Author: hp
 */

#include "EEPROM_Access.h"
#include "math.h"
#include "string.h"

// Define the I2C
extern I2C_HandleTypeDef hi2c2;
#define EEPROM_I2C &hi2c2

// EEPROM ADDRESS (8bits)

// Define the Page Size and number of pages
#define PAGE_SIZE 64     // in Bytes
#define PAGE_NUM  512    // number of pages

uint8_t bytes_temp[4];


void EEPROM_isDeviceReady(uint16_t addr)
{
	if (HAL_I2C_IsDeviceReady(&hi2c2, addr, 3, 100)==HAL_OK){
		for (int i=0; i<20; i++){
			HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
			HAL_Delay(100);
		}
	}
}

// function to determine the remaining bytes
uint16_t bytestowrite (uint16_t size, uint16_t offset)
{
	if ((size+offset)<PAGE_SIZE) return size;
	else return PAGE_SIZE-offset;
}

void EEPROM_Write (uint16_t page, uint16_t offset, uint8_t *data, uint16_t size)
{

	// Find out the number of bit, where the page addressing starts
	int paddrposition = log(PAGE_SIZE)/log(2);

	// calculate the start page and the end page
	uint16_t startPage = page;
	uint16_t endPage = page + ((size+offset)/PAGE_SIZE);

	// number of pages to be written
	uint16_t numofpages = (endPage-startPage) + 1;
	uint16_t pos=0;

	// write the data
	for (int i=0; i<numofpages; i++)
	{
		/* calculate the address of the memory location
		 * Here we add the page address with the byte address
		 */
		uint16_t MemAddress = startPage<<paddrposition | offset;
		uint16_t bytesremaining = bytestowrite(size, offset);  // calculate the remaining bytes to be written

		HAL_I2C_Mem_Write(EEPROM_I2C, EEPROM_ADDRESS, MemAddress, 2, &data[pos], bytesremaining, 1000);  // write the data to the EEPROM

		startPage += 1;  // increment the page, so that a new page address can be selected for further write
		offset=0;   // since we will be writing to a new page, so offset will be 0
		size = size-bytesremaining;  // reduce the size of the bytes
		pos += bytesremaining;  // update the position for the data buffer

		HAL_Delay (5);  // Write cycle delay (5ms)
	}
}

void EEPROM_Read (uint16_t page, uint16_t offset, uint8_t *data, uint16_t size)
{
	int paddrposition = log(PAGE_SIZE)/log(2);

	uint16_t startPage = page;
	uint16_t endPage = page + ((size+offset)/PAGE_SIZE);

	uint16_t numofpages = (endPage-startPage) + 1;
	uint16_t pos=0;

	for (int i=0; i<numofpages; i++)
	{
		uint16_t MemAddress = startPage<<paddrposition | offset;
		uint16_t bytesremaining = bytestowrite(size, offset);
		HAL_I2C_Mem_Read(EEPROM_I2C, EEPROM_ADDRESS, MemAddress, 2, &data[pos], bytesremaining, 1000);
		startPage += 1;
		offset=0;
		size = size-bytesremaining;
		pos += bytesremaining;
	}
}

void EEPROM_WriteChar(uint16_t addr, char data_char[])
{
	int len=0,j;
	len=strlen(data_char);
	for(j=0;j<=len;j++)
	{
		uint8_t data_write=data_char[j];
		HAL_I2C_Mem_Write(&hi2c2,EEPROM_ADDRESS,addr+j,64,&data_write,1,10);
		HAL_Delay(100);
	}
}

uint8_t EEPROM_ReadData(uint16_t addr)
{
	uint8_t EEPROM_data;
	HAL_I2C_Mem_Read(&hi2c2,0xA0,addr,64,&EEPROM_data,1,10);
	HAL_Delay(1);
	return EEPROM_data;
}

void EEPROM_ReadChar(uint16_t addr0, uint16_t addrn, uint8_t data_read_char[])
{
	uint8_t i;
	for(i=0;i<=(addrn-addr0);i++)
	{
		data_read_char[i]=EEPROM_ReadData(addr0+i);
	}
}

void EEPROM_PageErase (uint16_t page)
{
	// calculate the memory address based on the page number
	int paddrposition = log(PAGE_SIZE)/log(2);
	uint16_t MemAddress = page<<paddrposition;

	// create a buffer to store the reset values
	uint8_t data[PAGE_SIZE];
	memset(data,0xff,PAGE_SIZE);

	// write the data to the EEPROM
	HAL_I2C_Mem_Write(EEPROM_I2C, EEPROM_ADDRESS, MemAddress, 2, data, PAGE_SIZE, 1000);

	HAL_Delay (5);  // write cycle delay
}



